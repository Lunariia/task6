package com.epam.hometask.six.data.exception;

public class DaoException extends Exception {

    public DaoException(String message){
        super(message);
    }

}
