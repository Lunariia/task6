package com.epam.hometask.six.data;

public enum BookFieldsType {
    TITLE,AUTHORS,PAGES,YEAR,PUBLISHER
}
